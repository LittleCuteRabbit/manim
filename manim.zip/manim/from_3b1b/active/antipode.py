from manimlib.imports import *


class NewSceneName(ThreeDScene):
    def construct(self):
        pass
