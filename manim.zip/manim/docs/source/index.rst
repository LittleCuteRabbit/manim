.. Manim documentation master file, created by
   sphinx-quickstart on Mon May 27 14:19:19 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Manim's documentation!
=================================

These docs are generated from the master branch of the
`Manim repo <https://github.com/3b1b/manim>`_. You can contribute by submitting
a pull request there.

.. toctree::
    :maxdepth: 2
    :caption: Contents

    about
    installation/index
    getting_started/index
    coordinate
    animation
    constants


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
