#!/usr/bin/env python
import manimlib

if __name__ == "__main__":
    manimlib.main()
